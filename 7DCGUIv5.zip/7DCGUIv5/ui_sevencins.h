/********************************************************************************
** Form generated from reading UI file 'sevencins.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEVENCINS_H
#define UI_SEVENCINS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_sevencins
{
public:
    QWidget *centralwidget;
    QStackedWidget *main;
    QWidget *home;
    QPushButton *myShoppingList;
    QFrame *drinkPictureFrame;
    QGraphicsView *drinkPicture;
    QPushButton *randomDrinkButton;
    QPushButton *searchButton;
    QPushButton *showCabinetButton;
    QPushButton *showFavoritesButton;
    QLabel *label;
    QTextEdit *drinkInfo;
    QWidget *resultsPage;
    QPushButton *return1;
    QWidget *shoppinglist;
    QPushButton *return2;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *sevencins)
    {
        if (sevencins->objectName().isEmpty())
            sevencins->setObjectName(QStringLiteral("sevencins"));
        sevencins->resize(734, 404);
        centralwidget = new QWidget(sevencins);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        main = new QStackedWidget(centralwidget);
        main->setObjectName(QStringLiteral("main"));
        main->setGeometry(QRect(-1, -1, 741, 381));
        home = new QWidget();
        home->setObjectName(QStringLiteral("home"));
        myShoppingList = new QPushButton(home);
        myShoppingList->setObjectName(QStringLiteral("myShoppingList"));
        myShoppingList->setGeometry(QRect(540, 340, 100, 23));
        drinkPictureFrame = new QFrame(home);
        drinkPictureFrame->setObjectName(QStringLiteral("drinkPictureFrame"));
        drinkPictureFrame->setGeometry(QRect(70, 60, 181, 181));
        drinkPictureFrame->setFrameShape(QFrame::StyledPanel);
        drinkPictureFrame->setFrameShadow(QFrame::Sunken);
        drinkPicture = new QGraphicsView(drinkPictureFrame);
        drinkPicture->setObjectName(QStringLiteral("drinkPicture"));
        drinkPicture->setGeometry(QRect(10, 10, 161, 161));
        randomDrinkButton = new QPushButton(home);
        randomDrinkButton->setObjectName(QStringLiteral("randomDrinkButton"));
        randomDrinkButton->setGeometry(QRect(90, 340, 100, 23));
        randomDrinkButton->setToolTipDuration(5);
        randomDrinkButton->setCheckable(true);
        searchButton = new QPushButton(home);
        searchButton->setObjectName(QStringLiteral("searchButton"));
        searchButton->setGeometry(QRect(60, 20, 75, 23));
        searchButton->setToolTipDuration(5);
        showCabinetButton = new QPushButton(home);
        showCabinetButton->setObjectName(QStringLiteral("showCabinetButton"));
        showCabinetButton->setGeometry(QRect(390, 340, 100, 23));
        showCabinetButton->setToolTipDuration(5);
        showFavoritesButton = new QPushButton(home);
        showFavoritesButton->setObjectName(QStringLiteral("showFavoritesButton"));
        showFavoritesButton->setGeometry(QRect(240, 340, 100, 23));
        showFavoritesButton->setToolTipDuration(5);
        label = new QLabel(home);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(70, 250, 181, 20));
        label->setFrameShape(QFrame::Box);
        label->setAlignment(Qt::AlignCenter);
        drinkInfo = new QTextEdit(home);
        drinkInfo->setObjectName(QStringLiteral("drinkInfo"));
        drinkInfo->setGeometry(QRect(350, 60, 341, 211));
        main->addWidget(home);
        resultsPage = new QWidget();
        resultsPage->setObjectName(QStringLiteral("resultsPage"));
        return1 = new QPushButton(resultsPage);
        return1->setObjectName(QStringLiteral("return1"));
        return1->setGeometry(QRect(20, 20, 75, 23));
        main->addWidget(resultsPage);
        shoppinglist = new QWidget();
        shoppinglist->setObjectName(QStringLiteral("shoppinglist"));
        return2 = new QPushButton(shoppinglist);
        return2->setObjectName(QStringLiteral("return2"));
        return2->setGeometry(QRect(20, 20, 75, 23));
        main->addWidget(shoppinglist);
        sevencins->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(sevencins);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        sevencins->setStatusBar(statusbar);

        retranslateUi(sevencins);

        main->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(sevencins);
    } // setupUi

    void retranslateUi(QMainWindow *sevencins)
    {
        sevencins->setWindowTitle(QApplication::translate("sevencins", "sevencins", Q_NULLPTR));
        myShoppingList->setText(QApplication::translate("sevencins", "My Shopping List", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        randomDrinkButton->setToolTip(QApplication::translate("sevencins", "Shows a random drink. Try something new!", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        randomDrinkButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        randomDrinkButton->setText(QApplication::translate("sevencins", "Surprise Me!", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        searchButton->setToolTip(QApplication::translate("sevencins", "Search for a drink or a specific ingredient.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        searchButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        searchButton->setText(QApplication::translate("sevencins", "Search", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        showCabinetButton->setToolTip(QApplication::translate("sevencins", "Shows what is currently in your cabinet.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        showCabinetButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        showCabinetButton->setText(QApplication::translate("sevencins", "My Cabinet", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        showFavoritesButton->setToolTip(QApplication::translate("sevencins", "Show your list of favorites.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        showFavoritesButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        showFavoritesButton->setText(QApplication::translate("sevencins", "Favorites", Q_NULLPTR));
        label->setText(QApplication::translate("sevencins", "Welcome to 7DC", Q_NULLPTR));
        return1->setText(QApplication::translate("sevencins", "Back", Q_NULLPTR));
        return2->setText(QApplication::translate("sevencins", "Back", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class sevencins: public Ui_sevencins {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEVENCINS_H
