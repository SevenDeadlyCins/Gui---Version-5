#include "sevencins.h"
#include "ui_sevencins.h"

sevencins::sevencins(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::sevencins)
{
    this->setWindowTitle(QString("7DC - Home"));
    drinkInfo = new QTextBrowser();
    drinkInfo->setText("Under Construction. Buttons will crash.");

    drinkName->setText(QString("Nothing to see here."));
    ui->setupUi(this);
}

sevencins::~sevencins()
{
    delete ui;
}


void sevencins::on_showFavoritesButton_clicked()
{
    ui->main->setCurrentIndex(1);
    this->setWindowTitle(QString("7DC - Favorites"));
}

void sevencins::on_showCabinetButton_clicked()
{
    ui->main->setCurrentIndex(1);
    this->setWindowTitle(QString("7DC - My Cabinet"));
}

void sevencins::on_myShoppingList_clicked()
{
    ui->main->setCurrentIndex(2);
    this->setWindowTitle(QString("7DC - Shopping List"));
}

void sevencins::on_randomDrinkButton_clicked()
{
    this->setWindowTitle(QString("7DC - ???"));
    this->drinkInfo->setText("Under Construction. Buttons will crash.");
    this->drinkName->setText(QString("Nothing to see here."));
}

void sevencins::on_return1_clicked()
{
    ui->main->setCurrentIndex(0);
    this->setWindowTitle(QString("7DC - Home"));
}

void sevencins::on_return2_clicked()
{
    ui->main->setCurrentIndex(0);
    this->setWindowTitle(QString("7DC - Home"));
}

void sevencins::on_searchButton_clicked()
{
    ui->main->setCurrentIndex(1);
    this->setWindowTitle(QString("7DC - Search"));
}

void sevencins::on_drinkName_linkActivated(const QString &link)
{

}

void sevencins::on_drinkName_windowTitleChanged(const QString &title)
{

}
